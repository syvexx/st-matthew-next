# St. Matthew UCC – Next.js Site

This is a ready-to-deploy Next.js (App Router) site for **St. Matthew United Church of Christ, Baltimore, MD**.

## Quick Start

1. Install Node.js LTS: https://nodejs.org
2. Install dependencies:
   ```bash
   npm install
   ```
3. Run locally:
   ```bash
   npm run dev
   ```
   Visit http://localhost:3000

## Deploy (Vercel)

1. Create a GitHub repo and push this folder.
2. Go to https://vercel.com → New Project → Import the repo → Deploy.
3. Add a custom domain if you have one (e.g., saintmatthewucc.org).

## Editing Content

Open `app/page.js` and edit the `CHURCH` object near the top.
- To change the hero image, replace `/public/hero.jpg` with your own and update the filename if needed.
- The “Plan Your Visit” form currently links to the church's Contact page (GET). You can replace it with a Formspree or other form processor later.

## Notes
- No Tailwind or shadcn needed. Styling is in `styles/globals.css`.
- Icons are from `lucide-react` and animations from `framer-motion`.
