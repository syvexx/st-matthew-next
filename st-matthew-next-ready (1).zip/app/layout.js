export const metadata = {
  title: "St. Matthew UCC | Baltimore, MD",
  description: "Recognizing and nurturing the Christ in each person we encounter.",
};

import "./globals.css";

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
